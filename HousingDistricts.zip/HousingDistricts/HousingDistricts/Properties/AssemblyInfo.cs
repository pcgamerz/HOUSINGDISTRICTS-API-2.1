﻿using System.Reflection;
using System.Runtime.InteropServices;
using System.Resources;

[assembly: AssemblyTitle("HousingDistricts")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Community")]
[assembly: AssemblyProduct("HousingDistricts 2.3")]
[assembly: AssemblyCopyright("Copyright © 2015-2017")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("2.5.1")]
[assembly: AssemblyFileVersion("2.5.1")]
[assembly: NeutralResourcesLanguageAttribute("en-US")]
[assembly: ComVisible(false)]
